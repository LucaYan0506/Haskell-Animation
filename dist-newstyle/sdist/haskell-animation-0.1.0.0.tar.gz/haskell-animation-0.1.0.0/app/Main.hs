import Graphics.Gloss
import Graphics.Gloss.Data.ViewPort
import Graphics.Gloss.Interface.Pure.Game

type Position = (Float, Float)
type Velocity = (Float, Float)

-- Ball data
data Ball = Ball
  { ballPos :: Position
  , ballVel :: Velocity
  }

-- Initial ball state
initialBall :: Ball
initialBall = Ball (0, 0) (150, 100)

-- Screen boundaries
width, height, offset :: Int
width = 600
height = 400
offset = 100

-- Update ball position and handle collision
updateBall :: Float -> Ball -> Ball
updateBall seconds (Ball (x, y) (vx, vy)) = Ball (x', y') (vx', vy')
  where
    x' = x + vx * seconds
    y' = y + vy * seconds
    vx' = if abs x' > fromIntegral width / 2 then -vx else vx
    vy' = if abs y' > fromIntegral height / 2 then -vy else vy

-- Drawing function
drawBall :: Ball -> Picture
drawBall (Ball (x, y) _) = translate x y $ color ballColor $ circleSolid 10
  where
    ballColor = dark red

-- Main function
main :: IO ()
main = play
  (InWindow "Bouncing Ball" (width, height) (offset, offset))
  white
  60
  initialBall
  drawBall
  (\_ b -> b)       -- Event handling (none in this case)
  updateBall        -- Update logic
